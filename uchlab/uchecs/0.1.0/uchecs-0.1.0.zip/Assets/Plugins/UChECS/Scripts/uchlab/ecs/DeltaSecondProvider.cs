namespace uchlab.ecs {
    public enum DeltaSecondProvider {
        Default,
        Fixed,
        Smooth,
        Unscaled
    }

    public enum UpdateTick{
        Default,
        Fixed,
        Late
    }
}