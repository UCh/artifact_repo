using UnityEngine;
namespace uchlab.ecs.zenject {
    public class LabelGenericAttribute : PropertyAttribute {

        public LabelGenericAttribute() {
        }
    }
}