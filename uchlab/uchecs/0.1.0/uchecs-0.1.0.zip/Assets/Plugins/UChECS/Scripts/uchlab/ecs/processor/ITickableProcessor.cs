namespace uchlab.ecs.processor {
    public interface ITickableProcessor {
        void Tick();
    }
}