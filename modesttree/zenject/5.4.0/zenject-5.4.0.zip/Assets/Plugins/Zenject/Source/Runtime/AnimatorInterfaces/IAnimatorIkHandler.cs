using System.Collections.Generic;
using UnityEngine;

namespace Zenject
{
    public interface IAnimatorIkHandler
    {
        void OnAnimatorIk();
    }
}

